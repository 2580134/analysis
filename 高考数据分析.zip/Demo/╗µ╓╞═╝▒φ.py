from pyecharts.charts import Line  #折线图所导入的包
from pyecharts import options as opts  #全局设置所导入的包
import numpy as np
import pandas as pd
def line1():
    line = (
        Line()#实例化Line
        .add_xaxis(list)#加入X轴数据
        .add_yaxis("一分一段比率",data_list)#加入Y轴数据
        .set_global_opts(title_opts=opts.TitleOpts(title="Line-基本示例"))#全局设置项
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    )
    return line

data = pd.read_excel("Data/res-100.xlsx")
list = []
for i in range(100):
    list.append(i)
list1 = []
df = data.iloc[ :, 1:]

print(type(df))
data = np.array(df) #先将数据框转换为数组
data_list = data.tolist()  #其次转换为列表
#print(np.array(data_list))  #以数组形式打出来方便看
for i in data_list:
     list1.append(i)
     print(i)
#print (list1)
#print(df)
line1().render('E:/课程设计/2020-2021-1数据采集课设/高考数据分析/高考数据分析/图表.html')#保存图片为HTML网页