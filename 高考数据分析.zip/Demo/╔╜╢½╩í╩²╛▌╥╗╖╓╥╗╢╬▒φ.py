import pandas as pd  #引入模块
import os
#file_path = "D:/test/test.py"

def transform(Sheet):
    data = pd.read_excel(Sheet,header=None) #读取文件
    print(data)
    data1 = data.iloc[:, 0:5]  # 按位置取某五列
    df = pd.DataFrame(data1) #转化数据
    df.dropna(axis=0, how='any', inplace=True)
    #print(df)
    return df

def main():

    #with pd.ExcelWriter('Data/山东.xls') as writer:

    file_path = "E:/课程设计/2020-2021-1数据采集课设/高考数据分析/各省高考一分一段表数据/2020-山东-选考一门.xls" #获得文件路径
    f = pd.ExcelFile(file_path)  # 打开文件
    for i in f.sheet_names:
        Sheet_name = pd.read_excel(file_path, i)
        #print(i)
        print(Sheet_name)

        df_new = transform(Sheet_name)
        print(df_new)

        data1 = Sheet_name.loc[:, 0:5]  # 按位置取某五列
        print(data1)
        df = pd.DataFrame(data1) #转化数据
        df.dropna(axis=0, how='any', inplace=True)
        print(df)


main()

