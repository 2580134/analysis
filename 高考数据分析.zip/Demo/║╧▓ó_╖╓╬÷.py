import os
import pandas as pd
import re

dir = 'E:/课程设计/2020-2021-1数据采集课设/高考数据分析/各省高考一分一段表汇总/文理科省市'
# 获取目录下所有的表
origin_file_list = os.listdir(dir)
#print(origin_file_list)

with pd.ExcelWriter('Data/合并.xls') as writer:
	# 循环遍历表格
    for i in origin_file_list:
        # 拼接每个文件的路径
        print(i)
        file_path = dir + '/' + i
        # 把表名赋予给对应的sheet
        sheet_name = i
        df = pd.read_excel(file_path)

		# 变相解决表格中第一行第一列为空的缺陷
        string = "".join(list(str(i) for i in df.index))

        # 判断如果索引都为数字，则不保留索引
        if string.isdigit():
            df.to_excel(writer, sheet_name,index=False)
        else:
            df.to_excel(writer, sheet_name)
    print("文件合并成功")
